// Optional original card illustrations.
